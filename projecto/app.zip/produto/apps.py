from django.apps import AppConfig


class ProdutoConfig(AppConfig):
    name = 'produto'
